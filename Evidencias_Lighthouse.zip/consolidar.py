from pathlib import Path
import json,csv,statistics,zipfile,datetime,collections,sys
from xml.dom import minidom as M
from copy import deepcopy
run=Path('dist/lighthouse-series')
profiles={'desktop':'Desktop','mobile4g':'Mobile 4G','mobile3g':'Mobile 3G'}
versions={'baseline':'Baseline','images':'Imagens','routes':'Rotas','interaction':'Interação','combined':'Combinada'}
metrics={'Nota':None,'FCP (s)':'first-contentful-paint','LCP (s)':'largest-contentful-paint','TBT (ms)':'total-blocking-time','CLS':'cumulative-layout-shift','SI (s)':'speed-index'}
rows=[]; group=collections.defaultdict(list);warnings=[];http_errors=[];times=[]
for pr in profiles:
 for j,v in enumerate(versions):
  for rep in range(1,11):
   path=run/f'{pr}_{v}_{rep:02}.json'
   if not path.exists():continue
   l=json.loads(path.read_bytes());u=f'http://127.0.0.1:{4173+j}/'
   assert l['finalDisplayedUrl']==u and not l.get('runtimeError') and l['configSettings']['formFactor']==('desktop' if pr=='desktop' else 'mobile')
   c=l['configSettings']; assert c['throttlingMethod']==('provided' if pr=='desktop' else 'simulate')
   if pr!='desktop': assert c['throttling']['cpuSlowdownMultiplier']==(4 if pr=='mobile4g' else 6)
   if l.get('runWarnings'):warnings.append((path.name,l['runWarnings']))
   http_errors.extend((path.name,q.get('url')) for q in l['audits']['network-requests']['details']['items'] if q.get('statusCode',0)>=400)
   vals={k:(round(l['categories']['performance']['score']*100) if a is None else l['audits'][a]['numericValue']/(1000 if '(s)' in k else 1)) for k,a in metrics.items()}
   rows.append(dict(perfil=pr,versao=v,rodada=rep,inicio_utc=l['fetchTime'],url=u,**vals))
   times.append(l['fetchTime']);group[pr,v].append(vals)
def save(file,rows):
 with (run/file).open('w',encoding='utf-8-sig',newline='') as fp:
  w=csv.DictWriter(fp,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
if not rows:sys.exit('Nenhum registro.')
def fmt(x,k):return format(x,'.3f' if k=='CLS' else '.2f').replace('.',',')
summary=[]
for (pr,v),rs in group.items():
 for k in metrics:
  vals=[r[k] for r in rs]
  summary.append(dict(perfil=pr,versao=v,metrica=k,n=len(vals),media=statistics.mean(vals),mediana=statistics.median(vals),desvio_padrao_amostral=statistics.stdev(vals) if len(vals)>1 else ''))
save('execucoes.csv',rows);save('estatisticas.csv',summary)
if len(rows)!=150 and '--partial' not in sys.argv:sys.exit('Coleta incompleta: '+str(len(rows)))
full=len(rows)==150
p=Path('dist/tcc-doc/TCC_Guilherme_Brito_revisado.docx')
with zipfile.ZipFile(p) as z:f={k:z.read(k) for k in z.namelist()}
x=M.parseString(f['word/document.xml']);b=x.getElementsByTagName('w:body')[0];a=[n for n in b.childNodes if n.nodeType==1]
def txt(n):return ''.join(t.firstChild.data for t in n.getElementsByTagName('w:t') if t.firstChild)
def put(n,s):
 ts=n.getElementsByTagName('w:t')
 for t in ts:
  while t.firstChild:t.removeChild(t.firstChild)
 ts[0].appendChild(x.createTextNode(s))
anchor=next(n for n in a if txt(n).startswith('5 CONSIDERAÇÕES'))
def ins(s,style):
 n=a[style].cloneNode(True);put(n,s);b.insertBefore(n,anchor)
def med(pr,v,k):return statistics.median(r[k] for r in group[pr,v])
def insert_table(pr):
 source=next(n for n in a if n.nodeName=='w:tbl' and 'FCP' in txt(n))
 n=source.cloneNode(True);trs=n.getElementsByTagName('w:tr')
 for tr,v in zip(trs[1:],versions):
  cells=tr.getElementsByTagName('w:tc')
  for cell,val in zip(cells,[versions[v]]+[fmt(med(pr,v,k),k) if group[pr,v] else '—' for k in metrics]):put(cell,val)
 b.insertBefore(n,anchor)
env=json.loads((run/'ambiente.json').read_bytes());number=len(rows)
ins('4.4 Série automatizada de auditorias da página inicial',next(i for i,n in enumerate(a) if txt(n).startswith('4.3 Diagnósticos')))
start=min(times);end=max(times)
ins(f'Em uma segunda coleta, o Lighthouse {l["lighthouseVersion"]} executou auditorias sequenciais da categoria Performance nas cinco portas locais. A série produziu {number} relatórios válidos. O piloto manual das seções anteriores foi analisado separadamente. A abertura de uma instância nova do Chrome a cada execução manteve isolados os dados de navegação. A ordem das versões e a ordem dos perfis foram alternadas entre rodadas.',next(i for i,n in enumerate(a) if txt(n).startswith('A preparação da aplicação')))
style=next(i for i,n in enumerate(a) if txt(n).startswith('A preparação da aplicação'))
ins(f'O ambiente da coleta utilizou {env["platform"]}, processador {env["cpu"]}, {env["ram"]/1024**3:.1f} GiB de memória identificada pelo sistema e Chrome em modo headless. A versão do navegador em cada auditoria consta no respectivo JSON. No perfil Desktop, a ferramenta utilizou as condições de rede e CPU disponíveis, sem limitação adicional. Para os perfis móveis, adotou-se o método de simulação do Lighthouse: RTT de 150 ms, vazão de 1.638,4 kbit/s e fator de CPU 4 no 4G; RTT de 400 ms, vazão de 400 kbit/s e fator de CPU 6 no 3G. Esses valores operacionalizam os perfis experimentais, sem representar conexões físicas medidas.',style)
for idx,pr in enumerate(profiles,3):
 if not any(group[pr,v] for v in versions):continue
 ins(f'Tabela {idx} — Medianas da série automatizada no perfil {profiles[pr]}',next(i for i,n in enumerate(a) if txt(n).startswith('Tabela 1 —')))
 insert_table(pr)
 counts=', '.join(f'{versions[v]} ({len(group[pr,v])})' for v in versions)
 ins('Fonte: elaboração própria. Número de auditorias por versão: '+counts+'.',style)
 if all(group[pr,v] for v in versions):
  ins(f'No perfil {profiles[pr]}, a mediana do LCP foi de {fmt(med(pr,"baseline","LCP (s)"),"LCP (s)")} s na baseline e de {fmt(med(pr,"combined","LCP (s)"),"LCP (s)")} s na versão Combinada. As respectivas medianas de TBT foram {fmt(med(pr,"baseline","TBT (ms)"),"TBT (ms)")} ms e {fmt(med(pr,"combined","TBT (ms)"),"TBT (ms)")} ms.',style)
if full:
 ins('4.4.1 Variabilidade das medições',next(i for i,n in enumerate(a) if txt(n).startswith('4.3 Diagnósticos')))
 ins('A Tabela 6 detalha a dispersão do LCP, métrica associada à apresentação do maior conteúdo visível. As diferenças entre versões devem ser interpretadas junto à variação entre rodadas. As estatísticas são expressas em segundos. DP indica o desvio-padrão amostral.',style)
 ins('Tabela 6 — Distribuição do LCP por versão e perfil (s)',next(i for i,n in enumerate(a) if txt(n).startswith('Tabela 1 —')))
 source=next(n for n in a if n.nodeName=='w:tbl' and 'FCP' in txt(n))
 table=source.cloneNode(True);trs=table.getElementsByTagName('w:tr')
 for cell,val in zip(trs[0].getElementsByTagName('w:tc'),['Versão','Perfil','Média','Mediana','DP','Mín.','Máx.']):put(cell,val)
 sample=trs[1].cloneNode(True)
 for tr in list(trs[1:]):table.removeChild(tr)
 for pr in profiles:
  for v in versions:
   vals=[r['LCP (s)'] for r in group[pr,v]]
   tr=sample.cloneNode(True);table.appendChild(tr)
   for cell,val in zip(tr.getElementsByTagName('w:tc'),[versions[v],profiles[pr]]+[fmt(k,'LCP') for k in (statistics.mean(vals),statistics.median(vals),statistics.stdev(vals),min(vals),max(vals))]):put(cell,val)
 b.insertBefore(table,anchor);ins('Fonte: elaboração própria. Cada linha resume dez auditorias.',style)
ins('As estatísticas foram calculadas a partir dos valores numéricos dos relatórios, antes do arredondamento para apresentação. O arquivo estatisticas.csv registra média, mediana e desvio-padrão amostral por condição e métrica. As variações observadas refletem as condições locais de teste e não quantificam a experiência de usuários em rede pública.',style)
for n in a:
 s=txt(n)
 if s.startswith('A coleta apresentada a seguir'):put(n,'A coleta manual documentada nesta seção corresponde ao piloto local. A seção 4.4 apresenta a série automatizada de repetições. As demais rotas e a avaliação em hospedagem com WebPageTest permanecem previstas para continuidade.')
 if s.startswith('A comparação local da página'):put(n,s.replace('Com uma observação por condição','No piloto, com uma observação por condição').replace('repetir as medições, ','')+f' A série automatizada acrescentou {number} auditorias locais da página inicial, descritas na seção 4.4.')
 if s.startswith('Este trabalho avalia') or s.startswith('This study evaluates'):
  put(n,s+(f' Uma segunda série acrescentou {number} auditorias automatizadas da página inicial.' if s.startswith('Este') else f' A second series added {number} automated home-page audits.'))
 if s.startswith('Wohlin et al. (2012) distinguem'):put(n,s.replace('Uma única observação por versão e perfil','No piloto, uma única observação por versão e perfil'))
if full:
 start_local=datetime.datetime.fromisoformat(start.replace('Z','+00:00')).astimezone(datetime.timezone(datetime.timedelta(hours=-3)))
 end_local=datetime.datetime.fromisoformat(end.replace('Z','+00:00')).astimezone(datetime.timezone(datetime.timedelta(hours=-3)))
 ins(f'A janela de coleta, considerada pelo início das auditorias, estendeu-se de {start_local:%d/%m/%Y %H:%M} a {end_local:%d/%m/%Y %H:%M} (UTC−3). A verificação dos arquivos identificou {len(warnings)} relatórios com alertas gerais do Lighthouse e {len(http_errors)} respostas HTTP com código de erro nos registros de rede. Todos os relatórios incluídos produziram pontuação de desempenho para a URL prevista.',style)
 for n in a:
  s=txt(n)
  if s.startswith('Para a etapa ampliada de coleta'):put(n,'A série automatizada aplicou três perfis de rede e processamento. Os valores efetivamente parametrizados são apresentados na seção 4.4. A seção 3.5 descreve o piloto manual que antecedeu essa coleta.')
  if s.startswith('Para a etapa ampliada, estão previstas'):put(n,'Na série automatizada, foram realizadas dez execuções por versão e perfil. Os relatórios registraram a configuração efetiva e os valores de cada métrica. Esse conjunto reúne 150 auditorias da Home e foi analisado separadamente das dez auditorias do piloto manual.')
  if s.startswith('Na etapa local, os valores'):put(n,'Para o piloto manual, compararam-se os valores de cada execução. Na série automatizada, calcularam-se a média, a mediana e o desvio-padrão amostral das dez repetições por condição. A análise de INP exigiria um roteiro de interação adicional.')
  if s.startswith('A comparação entre tratamentos toma'):put(n,s.replace('A repetição das medições na etapa ampliada permitirá examinar','As repetições da série automatizada permitiram examinar'))
  if s.startswith('Dados de laboratório descrevem'):put(n,s.replace('uma observação de laboratório da Home para cada condição','observações de laboratório da Home para cada condição'))
  if s.startswith('A comparação local da página'):
   t=' '.join(f'No perfil {profiles[pr]}, as medianas do LCP foram {fmt(med(pr,"baseline","LCP (s)"),"LCP")} s na baseline e {fmt(med(pr,"combined","LCP (s)"),"LCP")} s na versão Combinada.' for pr in profiles)
   put(n,'A avaliação da Home compreendeu dez auditorias manuais exploratórias e 150 auditorias automatizadas com repetição. '+t+' A leitura conjunta das métricas e da dispersão entre rodadas delimita a interpretação ao equipamento e aos perfis adotados. A avaliação de outras rotas e do primeiro uso dos modais, assim como a coleta em hospedagem pública, constituem etapas de continuidade.')
f['word/document.xml']=x.toxml(encoding='utf-8')
out=run/'TCC_Guilherme_Brito_revisado.docx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for k,v in f.items():z.writestr(k,v)
with zipfile.ZipFile(run/'Evidencias_Lighthouse.zip','w',zipfile.ZIP_DEFLATED) as z:
 for file in [*run.glob('*.json'),*run.glob('*.csv'),Path('dist/lighthouse-tools/coleta.mjs'),Path('dist/lighthouse-tools/consolidar.py'),Path('dist/lighthouse-tools/package-lock.json')]:z.write(file,file.name)
print(number, 'auditorias;',len(warnings),'com alertas;',len(http_errors),'erros HTTP')
